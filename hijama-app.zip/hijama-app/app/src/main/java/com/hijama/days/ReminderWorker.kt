package com.hijama.days

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("hijama", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("notify", true)) return Result.success()

        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        if (hour < 8 || hour >= 22) return Result.success()   // لا إزعاج ليلًا

        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now.time)
        if (prefs.getString("last", "") == key) return Result.success()

        val offset = prefs.getInt("offset", 0)
        val tomorrow = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }

        when {
            HijamaCalc.isBest(now, offset) -> Notifier.show(
                applicationContext, "اليوم يوم حجامة 🌙",
                "${HijamaCalc.label(now, offset)} من أفضل أيام الحجامة. والحجامة على الريق أمثل."
            )
            HijamaCalc.isBest(tomorrow, offset) -> Notifier.show(
                applicationContext, "غدًا يوم حجامة 🌙",
                "${HijamaCalc.label(tomorrow, offset)} من أفضل أيام الحجامة، فاستعد واحجز موعدك."
            )
        }
        prefs.edit().putString("last", key).apply()
        return Result.success()
    }
}
