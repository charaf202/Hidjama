package com.hijama.days

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(applicationContext), "Android")
        web.loadUrl("file:///android_asset/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        schedule(applicationContext)
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<ReminderWorker>(3, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("hijama_reminder", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

class Bridge(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("hijama", Context.MODE_PRIVATE)

    @JavascriptInterface fun getOffset(): Int = prefs.getInt("offset", 0)
    @JavascriptInterface fun setOffset(v: Int) {
        prefs.edit().putInt("offset", v).putString("last", "").apply()
    }
    @JavascriptInterface fun getNotify(): Boolean = prefs.getBoolean("notify", true)
    @JavascriptInterface fun setNotify(v: Boolean) {
        prefs.edit().putBoolean("notify", v).apply()
    }
    @JavascriptInterface fun testNotify() {
        Notifier.show(ctx, "أيام الحجامة 🌙", "التنبيهات تعمل. سيصلك تنبيه قبل كل يوم من أفضل أيام الحجامة بيوم، وتنبيه في اليوم نفسه.")
    }
}
