package com.hijama.days

import android.icu.util.IslamicCalendar
import java.util.Calendar
import android.icu.util.Calendar as ICal

object HijamaCalc {
    val MONTHS = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )
    private val DAYS = mapOf(
        Calendar.SUNDAY to "الأحد", Calendar.MONDAY to "الاثنين", Calendar.TUESDAY to "الثلاثاء",
        Calendar.WEDNESDAY to "الأربعاء", Calendar.THURSDAY to "الخميس",
        Calendar.FRIDAY to "الجمعة", Calendar.SATURDAY to "السبت"
    )

    /** returns [day, month(1-12), year] */
    fun hijri(c: Calendar, offset: Int): IntArray {
        val d = c.clone() as Calendar
        d.add(Calendar.DAY_OF_MONTH, offset)
        val ic = IslamicCalendar()
        ic.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA)
        ic.timeInMillis = d.timeInMillis
        return intArrayOf(ic.get(ICal.DAY_OF_MONTH), ic.get(ICal.MONTH) + 1, ic.get(ICal.YEAR))
    }

    fun isBest(c: Calendar, offset: Int): Boolean {
        val wd = c.get(Calendar.DAY_OF_WEEK)
        if (wd != Calendar.MONDAY && wd != Calendar.TUESDAY && wd != Calendar.THURSDAY) return false
        val day = hijri(c, offset)[0]
        return day == 17 || day == 19 || day == 21
    }

    fun label(c: Calendar, offset: Int): String {
        val h = hijri(c, offset)
        return "${DAYS[c.get(Calendar.DAY_OF_WEEK)]} ${h[0]} ${MONTHS[h[1] - 1]}"
    }
}
